# Lektion 7: Alles in ein echtes Skript packen

Bisher hast du alles direkt in PowerShell eingetippt. Schließt du das Fenster, ist alles weg. Ein **Skript** ist eine Textdatei, in der deine Befehle untereinander stehen. PowerShell arbeitet sie von oben nach unten ab, als hättest du sie nacheinander eingetippt.

## Datei anlegen

1. Öffne den **Editor** (Windows-Taste, „Editor“ eintippen).
2. Schreib deine Befehle untereinander.
3. Speichere die Datei mit der Endung **`.ps1`**, zum Beispiel `checkup.ps1`. Wähle bei „Dateityp“ **„Alle Dateien“**, sonst hängt der Editor heimlich `.txt` an.
4. Speicher sie am besten in einem eigenen Ordner, zum Beispiel `C:\Skripte`.

## Kommentare

Alles hinter einer **Raute `#`** ignoriert PowerShell. So hinterlässt du Notizen für dich und andere:

```powershell
# Hier prüfe ich den Festplattenplatz
```

Das hilft enorm, wenn du das Skript nach Monaten wieder öffnest. Im Job wird das auch erwartet.

## Skript starten

In PowerShell wechselst du in den Ordner und startest das Skript mit Punkt und Backslash davor:

```powershell
cd C:\Skripte
.\checkup.ps1
```

## Fehlermeldung: „Ausführung von Skripts ist deaktiviert“

Beim ersten Start erscheint oft eine Meldung, dass die Datei nicht geladen werden kann, weil die **Ausführung von Skripts auf diesem System deaktiviert** ist. Das ist kein Fehler in deinem Code, sondern eine **Sicherheitseinstellung** von Windows (die *Execution Policy*). Sie verhindert, dass versehentlich fremde Skripte ausgeführt werden.

Für deinen eigenen Benutzer kannst du sie so lockern:

```powershell
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
```

**RemoteSigned** bedeutet: Skripte, die du selbst auf deinem PC geschrieben hast, dürfen laufen. Skripte aus dem Internet müssen dagegen digital signiert sein. `-Scope CurrentUser` sorgt dafür, dass die Änderung nur für dein Benutzerkonto gilt.

> **Hinweis:** Auf Firmen- oder Schulrechnern wird diese Einstellung oft zentral von der IT festgelegt. Dort solltest du nichts daran ändern, sondern im Zweifel nachfragen.

## 🛠️ Aufgabe

1. Leg eine Datei `checkup.ps1` an.
2. Schreib den **Festplatten-Teil** hinein (Laufwerk holen, Gesamtgröße, Prozent ausrechnen, runden, `if`/`else`) und darunter den **Dienste-Teil**. Du hast alle Teile in den Lektionen 4 bis 6 schon geschrieben, du musst sie nur zusammensetzen. Den Testwert aus Lektion 5 lässt du natürlich weg.
3. Setz über jeden Teil einen Kommentar, der erklärt, was dort passiert.
4. Starte das Skript.

---

⬅️ [Lektion 6](06-dienste.md) | 🏠 [Zur Übersicht](../README.md)
