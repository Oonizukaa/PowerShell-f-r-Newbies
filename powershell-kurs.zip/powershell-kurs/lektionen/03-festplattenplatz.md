# Lektion 3: Festplattenplatz abfragen

## Das Cmdlet

```powershell
Get-PSDrive C
```

Das bedeutet: „Hol mir die Infos zum Laufwerk C“. Du bekommst eine Tabelle mit Spalten wie **Used** (belegt) und **Free** (frei).

## Eigenschaften

So eine Tabelle besteht aus einzelnen Infos, die man **Eigenschaften** nennt. Steckst du das Ergebnis in eine Variable, kannst du einzelne Eigenschaften mit einem **Punkt** herausholen:

```powershell
$laufwerk = Get-PSDrive C
$laufwerk.Free
```

Das liest man so: „Aus der Schachtel *laufwerk* hol mir nur die Info *Free*.“

## 🛠️ Aufgabe

1. Führe `Get-PSDrive C` aus und schau dir die Tabelle an.
2. Speichere das Ergebnis in `$laufwerk` und lass dir einzeln `$laufwerk.Free` und `$laufwerk.Used` anzeigen.
3. **Knobelfrage:** Die Zahlen sind riesig und sehen anders aus als in der Tabelle. In welcher Einheit sind sie wohl angegeben?

<details>
<summary><b>Lösung anzeigen</b></summary>

```powershell
Get-PSDrive C
$laufwerk = Get-PSDrive C
$laufwerk.Free
$laufwerk.Used
```

**Zu 3:** Die Werte sind in **Bytes** angegeben, der kleinsten Einheit für Speicherplatz. Ein Gigabyte sind rund eine Milliarde Bytes. Die Tabelle rechnet netterweise schon in GB um, die Eigenschaften liefern aber die Rohdaten.

</details>

---

⬅️ [Lektion 2](02-variablen.md) | ➡️ Weiter zu [Lektion 4: Rechnen](04-rechnen.md)
