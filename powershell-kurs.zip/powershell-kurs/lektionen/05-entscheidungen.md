# Lektion 5: Entscheidungen treffen

Ein Checkup-Skript soll nicht nur Zahlen anzeigen, sondern selbst beurteilen: „Wenn zu wenig Platz frei ist, dann warne mich.“

## if und else

```powershell
if (BEDINGUNG) {
    Das passiert, wenn die Bedingung stimmt
}
else {
    Das passiert, wenn die Bedingung NICHT stimmt
}
```

`if` heißt „wenn“, `else` heißt „ansonsten“. Die geschweiften Klammern `{ }` sind wie ein Karton, in dem die Befehle für den jeweiligen Fall liegen.

Tippst du das direkt in PowerShell ein, wartet es nach der ersten `{` mit `>>` auf den Rest, bis alle Klammern geschlossen sind.

## Vergleichen

PowerShell benutzt für Vergleiche **nicht** `<` und `>`, sondern Abkürzungen mit Bindestrich:

| Vergleich | Bedeutung | Englisch |
|---|---|---|
| `-lt` | kleiner als | less than |
| `-gt` | größer als | greater than |
| `-eq` | gleich | equal |

`$freiProzent -lt 15` fragt also: „Ist `$freiProzent` kleiner als 15?“

## Text ausgeben

```powershell
Write-Host "Hallo"
Write-Host "Achtung!" -ForegroundColor Red
Write-Host "Alles gut" -ForegroundColor Green
```

## Testen mit Testwerten

Wie prüfst du, ob deine Warnung funktioniert, ohne die Festplatte vollzumüllen? Ganz einfach: Du legst vorübergehend einen **Testwert** in die Variable.

```powershell
$freiProzent = 10
```

Für deine `if`-Abfrage sieht es dann so aus, als wäre die Platte fast voll, obwohl sich am echten Laufwerk nichts ändert. Das ist in der IT eine absolute Standardtechnik.

Tipp: Mit der **Pfeiltaste nach oben** holst du frühere Befehle zurück.

## 🛠️ Aufgabe

1. Schreib eine `if`-Abfrage, die prüft, ob `$freiProzent` kleiner als 15 ist. Wenn ja, soll in Rot eine Warnung erscheinen, ansonsten in Grün eine Entwarnung.
2. Teste mit einem Testwert, ob die Warnung wirklich erscheint.
3. Stell danach den echten Wert wieder her, indem du die Prozent-Rechnung aus Lektion 4 nochmal ausführst.

<details>
<summary><b>Lösung anzeigen</b></summary>

```powershell
# 1.
if ($freiProzent -lt 15) {
    Write-Host "Warnung: Wenig Speicherplatz!" -ForegroundColor Red
}
else {
    Write-Host "Genug Speicherplatz frei" -ForegroundColor Green
}

# 2. Testwert setzen und die if-Abfrage erneut ausführen
$freiProzent = 10
```

Nach dem Testwert erscheint die rote Warnung. Damit weißt du, dass **beide** Wege funktionieren.

</details>

## ⚠️ Häufige Fehler

- **Kein `else`:** Ist die Bedingung nicht erfüllt, passiert einfach gar nichts. Das ist kein Fehler, aber verwirrend. Mit `else` bekommst du immer eine Rückmeldung.
- **Leerzeichen fehlt:** `-lt14` statt `-lt 14`.
- **Falsche Richtung beim Testen:** Willst du die Warnung auslösen, muss der Testwert *unter* der Grenze liegen (oder die Grenze *über* dem echten Wert).

---

⬅️ [Lektion 4](04-rechnen.md) | ➡️ Weiter zu [Lektion 6: Dienste](06-dienste.md)
