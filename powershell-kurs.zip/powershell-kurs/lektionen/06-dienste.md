# Lektion 6: Dienste prüfen

## Was sind Dienste?

**Dienste** sind Programme, die unsichtbar im Hintergrund laufen und wichtige Aufgaben erledigen. Der Dienst **Spooler** (die Druckwarteschlange) sorgt zum Beispiel dafür, dass Druckaufträge beim Drucker ankommen. Läuft er nicht, kann niemand drucken.

## Einen bestimmten Dienst abfragen

Mit dem Parameter `-Name` holst du dir gezielt **einen** Dienst:

```powershell
Get-Service -Name Spooler
```

Das funktioniert genau wie beim Laufwerk: Ergebnis in eine Variable speichern und mit dem Punkt eine Eigenschaft herausholen. Die wichtige Eigenschaft heißt **Status** und hat meistens den Wert `Running` oder `Stopped`.

Vergleichst du mit einem **Text**, kommt der Text in Anführungszeichen: `-eq "Running"`.

## 🛠️ Aufgabe

1. Hol dir den Dienst Spooler und speichere ihn in `$dienst`.
2. Lass dir nur den Status dieses Dienstes anzeigen.
3. Schreib eine `if`-Abfrage: Wenn der Status gleich „Running“ ist, soll in Grün gemeldet werden, dass der Dienst läuft, ansonsten in Rot, dass er nicht läuft.

<details>
<summary><b>Lösung anzeigen</b></summary>

```powershell
# 1.
$dienst = Get-Service -Name Spooler

# 2.
$dienst.Status

# 3.
if ($dienst.Status -eq "Running") {
    Write-Host "Spooler läuft" -ForegroundColor Green
}
else {
    Write-Host "Spooler läuft NICHT" -ForegroundColor Red
}
```

</details>

## ⚠️ Häufige Fehler

- **Zum Anzeigen ein Gleichheitszeichen benutzen:** `$dienst = $dienst.Status` überschreibt die Variable. Zum Anzeigen reicht `$dienst.Status`.
- **Das ganze Objekt vergleichen:** `$dienst -eq "Running"` vergleicht den kompletten Dienst. Du willst aber nur die Eigenschaft: `$dienst.Status`.
- **Anführungszeichen vergessen:** Ohne `"Running"` hält PowerShell das Wort für einen Befehl.

---

⬅️ [Lektion 5](05-entscheidungen.md) | ➡️ Weiter zu [Lektion 7: Das fertige Skript](07-skript.md)
