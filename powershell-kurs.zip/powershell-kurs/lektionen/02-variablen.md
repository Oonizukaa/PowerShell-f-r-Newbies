# Lektion 2: Variablen

## Was ist eine Variable?

Stell dir eine **Variable** wie eine beschriftete Schachtel vor. Du legst etwas hinein und kannst es später über den Namen der Schachtel wieder herausholen.

In PowerShell erkennst du Variablen am **Dollarzeichen `$`**:

```powershell
$stadt = "Aachen"
```

Das liest man so: „Leg das Wort *Aachen* in die Schachtel namens *stadt*.“ Das Gleichheitszeichen bedeutet hier also nicht „ist gleich“ wie in Mathe, sondern **„speichere hinein“**.

Um den Inhalt anzuzeigen, tippst du einfach den Namen ein:

```powershell
$stadt
```

## Wichtig zu wissen

- Text kommt in **Anführungszeichen** (`"Aachen"`), Zahlen nicht (`$alter = 20`).
- Du kannst auch das **Ergebnis eines Cmdlets** speichern: `$jetzt = Get-Date`. Das brauchen wir später ständig: Infos holen, in einer Variable aufbewahren und damit weiterarbeiten.
- Legst du etwas Neues in eine Variable, wird der alte Inhalt **überschrieben**.
- Mit einem **Semikolon `;`** kannst du mehrere Befehle in eine Zeile schreiben.

## 🛠️ Aufgabe

1. Erstelle eine Variable `$name` mit deinem Namen und lass sie dir anzeigen.
2. Speichere das Ergebnis von `Get-Date` in `$jetzt`. Warte ein paar Sekunden und lass dir `$jetzt` anzeigen. Führe zum Vergleich nochmal direkt `Get-Date` aus. **Was fällt dir an den Uhrzeiten auf, und warum?**
3. Speichere zwei Zahlen in `$a` und `$b` und probier aus, was `$a + $b` ergibt.

<details>
<summary><b>Lösung anzeigen</b></summary>

```powershell
# 1.
$name = "Max"
$name

# 2.
$jetzt = Get-Date
$jetzt
Get-Date

# 3.
$a = 2 ; $b = 3 ; $a + $b
```

**Zu 2:** `$jetzt` zeigt immer die Uhrzeit von dem Moment, als die Variable befüllt wurde. `Get-Date` holt dagegen jedes Mal die aktuelle Uhrzeit. Eine Variable ist wie ein **Foto**: Sie hält einen Zustand fest und aktualisiert sich nicht von selbst.

</details>

## ⚠️ Häufige Fehler

- **Dollarzeichen vergessen:** `name` statt `$name`. PowerShell hält das Wort dann für einen Befehl und meldet, dass es ihn nicht kennt.
- **Falsches Zeichen:** `%name` statt `$name`. Variablen beginnen immer mit `$`.

---

⬅️ [Lektion 1](01-powershell-und-cmdlets.md) | ➡️ Weiter zu [Lektion 3: Festplattenplatz](03-festplattenplatz.md)
