# Lektion 1: PowerShell und Cmdlets

## Was ist PowerShell?

PowerShell ist ein Fenster, in das du Befehle eintippst, statt mit der Maus herumzuklicken. Statt dich durch fünf Menüs zu klicken, um zu sehen, welche Dienste laufen, schreibst du einen einzigen Befehl.

## Was ist ein Cmdlet?

**Cmdlets** (gesprochen „Commandlets“) sind die Befehle in PowerShell. Sie sind alle nach demselben Muster benannt:

> **Verb-Nomen**, also **Tätigkeit-Ding**

| Cmdlet | Bedeutung |
|---|---|
| `Get-Date` | Hol mir das Datum |
| `Get-Service` | Hol mir die Dienste |
| `Stop-Service` | Stoppe einen Dienst |

Das Verb `Get` (holen/anzeigen) wirst du am häufigsten benutzen. Es zeigt nur etwas an und verändert nichts, du kannst damit also gefahrlos ausprobieren.

Groß- und Kleinschreibung ist PowerShell übrigens egal: `get-process` und `Get-Process` funktionieren gleich. Die Schreibweise mit Großbuchstaben ist nur besser lesbar.

## PowerShell öffnen

Drück die **Windows-Taste**, tippe `PowerShell` ein und klicke auf **Windows PowerShell**. Es erscheint eine Zeile wie `PS C:\Users\Name>`. Dahinter tippst du deine Befehle ein und bestätigst mit **Enter**.

## 🛠️ Aufgabe

1. Führe `Get-Date` aus. Was siehst du?
2. Führe `Get-Service` aus. Welche zwei verschiedenen Werte tauchen in der Spalte **Status** auf?
3. **Knobelfrage:** Laufende Programme heißen auf Englisch *Processes*. Wie könnte das Cmdlet heißen, das dir alle laufenden Programme anzeigt? Rate mit dem Verb-Nomen-Muster und probier es aus.

<details>
<summary><b>Lösung anzeigen</b></summary>

1. Das aktuelle Datum mit Uhrzeit, sekundengenau.
2. **Running** (läuft) und **Stopped** (gestoppt). Diese Spalte wird später für das Checkup-Skript wichtig.
3. `Get-Process`

</details>

---

➡️ Weiter zu [Lektion 2: Variablen](02-variablen.md)
