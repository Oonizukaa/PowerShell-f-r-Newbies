# Lektion 4: Rechnen und umrechnen

## Bytes in Gigabyte

PowerShell kennt die Speichereinheiten schon. Du kannst einfach `1GB` schreiben (ohne Leerzeichen). Zum Umrechnen teilst du durch `1GB`. Das Zeichen für „geteilt durch“ ist der **Schrägstrich `/`**:

```powershell
$laufwerk.Free / 1GB
```

## Runden

Das Ergebnis hat viele Nachkommastellen. Zum Runden gibt es:

```powershell
[math]::Round(ZAHL, 2)
```

In die Klammer kommt zuerst die Zahl, dann ein Komma, dann die Anzahl der gewünschten Nachkommastellen. Statt einer festen Zahl kannst du auch eine **Variable** einsetzen:

```powershell
$preis = 9.87654
[math]::Round($preis, 2)    # ergibt 9,88
```

> **Hinweis:** Im Code schreibst du Kommazahlen mit **Punkt** (`9.87`). Auf einem deutschen Windows zeigt PowerShell das Ergebnis aber mit **Komma** an (`9,88`).

## Prozent ausrechnen

Die Frage bei Prozent ist immer: **Welcher Anteil vom Ganzen ist das?** Anteil bedeutet: teilen.

> Prozent frei = (frei geteilt durch gesamt) mal 100

**Beispiel:** 20 GB belegt, 60 GB frei, also 80 GB gesamt. 60 / 80 = 0,75. Mal 100 sind das **75 %**.

Mal rechnest du in PowerShell mit dem **Sternchen `*`**. Und wie in Mathe gilt: Klammer zuerst.

## 🛠️ Aufgabe

1. Lass dir den freien Speicherplatz von Laufwerk C in GB anzeigen.
2. Speichere das Ergebnis in `$freiGB` und runde es auf 2 Nachkommastellen.
3. Rechne die Gesamtgröße aus (`$laufwerk.Used` plus `$laufwerk.Free`) und speichere sie in `$gesamt`.
4. Rechne aus, wie viel Prozent frei sind, speichere es in `$freiProzent` und runde auf 2 Stellen.

<details>
<summary><b>Lösung anzeigen</b></summary>

```powershell
$laufwerk = Get-PSDrive C

# 1. und 2.
$freiGB = $laufwerk.Free / 1GB
$freiGB = [math]::Round($freiGB, 2)
$freiGB

# 3.
$gesamt = $laufwerk.Used + $laufwerk.Free

# 4.
$freiProzent = ($laufwerk.Free / $gesamt) * 100
$freiProzent = [math]::Round($freiProzent, 2)
$freiProzent
```

Bei der Prozentrechnung musst du nicht in GB umrechnen: Weil du Bytes durch Bytes teilst, kürzt sich die Einheit weg.

</details>

## ⚠️ Häufige Fehler

- **Dollarzeichen in der Rechnung vergessen:** `($laufwerk.Free / gesamt)` statt `/ $gesamt`. Die Fehlermeldung lautet dann ungefähr *„Der Begriff ‚gesamt‘ wurde nicht als Name eines Cmdlet … erkannt“*. Die Meldung verrät dir also genau, an welchem Wort es hakt.
- **Prozent falsch gedacht:** „100 % minus belegte GB“ funktioniert nur zufällig, wenn die Platte genau 100 GB groß ist. Richtig ist immer: Anteil = frei geteilt durch gesamt.
- **Eine Variable für zwei Dinge benutzen:** Es funktioniert, ist aber unübersichtlich. Besser: Jede Variable enthält nur eine Sache, und der Name passt dazu.

---

⬅️ [Lektion 3](03-festplattenplatz.md) | ➡️ Weiter zu [Lektion 5: Entscheidungen](05-entscheidungen.md)
